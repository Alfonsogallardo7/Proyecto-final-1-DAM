package com.salesianostriana.dam.proyectofinal.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.salesianostriana.dam.proyectofinal.modelo.Competidor;

public interface CompetidorRepository extends JpaRepository<Competidor, Long> {
	

}
