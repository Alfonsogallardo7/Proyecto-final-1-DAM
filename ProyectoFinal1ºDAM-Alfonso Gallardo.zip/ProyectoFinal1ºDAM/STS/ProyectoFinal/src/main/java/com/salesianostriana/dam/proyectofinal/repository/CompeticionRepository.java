package com.salesianostriana.dam.proyectofinal.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.salesianostriana.dam.proyectofinal.modelo.Competicion;

public interface CompeticionRepository
	extends JpaRepository<Competicion, Long>{

}
